#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define WEAPON_NAME_MAX_SIZE 16

typedef enum weapon_type_e {
    TOOTHPICK,
    DAGGER,
    AXE,
    BOW,
    SHIELD,
    SWORD,
    LONGSWORD,
    SPEAR,
    EPICSHIELD,
    KATANA,
} weapon_type;

typedef enum foe_type_e {
    FLEA=0,
    FISH=1,
    BUTTERFLY=2,
    DOG=3,
    BAT=4,
    DRAGON=5,
    BIGBOSSDRAGON=6,
} foe_type;

typedef enum strike_outcome_e {
    HERO_DEAD,
    FOE_DEAD,
    BOTH_DEAD,
    BOTH_SURVIVED,
} strike_outcome_e;

typedef enum hands_e {
    LEFT,
    RIGHT,
} hands_e;

typedef struct hero_s {
    int health;
    hands_e main_hand;
    void* left_hand;
    void* right_hand;
} hero_t;

typedef struct weapon_s {
    weapon_type type;
    int damage;
    unsigned int defense;
    unsigned int level;
} weapon_t;

typedef struct toothpick_s {
    weapon_t weapon;
    char art[8];
    char name[WEAPON_NAME_MAX_SIZE];
} toothpick_t;

typedef struct dagger_s {
    weapon_t weapon;
    char art[0x10 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} dagger_t;

typedef struct axe_s {
    weapon_t weapon;
    char art[0x20 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} axe_t;

typedef struct bow_s {
    weapon_t weapon;
    char art[0x30 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} bow_t;

typedef struct shield_s {
    weapon_t weapon;
    char art[0x40 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} shield_t;

typedef struct sword_s {
    weapon_t weapon;
    char art[0x50 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} sword_t;

typedef struct longsword_s {
    weapon_t weapon;
    char art[0x60 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} longsword_t;

typedef struct spear_s {
    weapon_t weapon;
    char art[0x70 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} spear_t;

typedef struct epic_shield_s {
    weapon_t weapon;
    char art[0x80 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} epic_shield_t;

typedef struct katana_s {
    weapon_t weapon;
    char art[0x90 + 8];
    char name[WEAPON_NAME_MAX_SIZE];
} katana_t;

typedef struct foe_s {
    foe_type type;
    int health;
    int damage;
    unsigned int defense;
    char art[];
} foe_t;

char* foe_names[] = {
        "cat flea",
        "slimy quick fish",
        "tiny beautiful butterfly",
        "cute looking throat ripping dogy",
        "very old Count Dracula blood-sucking bat",
        "not as bad as big boss but still very bad dragon",
        "big and bad but also very loving big boss dragon",
    };
char* foe_arts[] = {
        ".",
        "  _\n><_>",
        "  \\ /\n(\\ o /)\n ))Y((\n(/ ^ \\)",
        "  __      _\no'')}____//\n `_/      )\n (_(_/-(_/",
        "  _   ,_,   _\n / `'=) (='` \\\n/.-.-.\\ /.-.-.\\\n`      \"      `",
        "# COMMON GRAY #\n      .\n .>   )\\;`a__\n(  _ _)/ /-.\" ~~\n `( )_ )/\n  <_  <_",
        "# BOSS DRAGON #\n      .\n .>   )\\;`a__\n(  _ _)/ /-.\" ~~\n `( )_ )/\n  <_  <_",
    };

hero_t* hero = NULL;
foe_t* foe = NULL;
unsigned int foes_fought = 0;
unsigned int FACED_BIG_BOSS = 0;

unsigned int readWeaponName(char* buf){
    printf("please insert a name: ");
    unsigned int name_len = read(1, buf, WEAPON_NAME_MAX_SIZE);
    buf[name_len-1] = '\0';
    return name_len;
}

unsigned int readChoice(unsigned int* choice){
    if(scanf("%u", choice) != 1){
        puts("error: invalid input (unsigned int)");
        exit(1);
    }
}

weapon_type getWeaponType(void* weapon){
    return ((weapon_t*) weapon)->type;
}

int getWeaponDamage(void* weapon){
    return ((weapon_t*) weapon)->damage;
}

unsigned int getWeaponDefense(void* weapon){
    return ((weapon_t*) weapon)->defense;
}

char* getWeaponArt(void* weapon){
    switch(getWeaponType(weapon)){
        case TOOTHPICK:
            return ((toothpick_t*) weapon)->art;
            break;
        case DAGGER:
            return ((dagger_t*) weapon)->art;
            break;
        case AXE:
            return ((axe_t*) weapon)->art;
            break;
        case BOW:
            return ((bow_t*) weapon)->art;
            break;
        case SHIELD:
            return ((shield_t*) weapon)->art;
            break;
        case SWORD:
            return ((sword_t*) weapon)->art;
            break;
        case LONGSWORD:
            return ((longsword_t*) weapon)->art;
            break;
        case SPEAR:
            return ((spear_t*) weapon)->art;
            break;
        case EPICSHIELD:
            return ((epic_shield_t*) weapon)->art;
            break;
        case KATANA:
            return ((katana_t*) weapon)->art;
            break;
        default:
            return "";
    }
}

char* getWeaponName(void* weapon){
    switch(getWeaponType(weapon)){
        case TOOTHPICK:
            return ((toothpick_t*) weapon)->name;
            break;
        case DAGGER:
            return ((dagger_t*) weapon)->name;
            break;
        case AXE:
            return ((axe_t*) weapon)->name;
            break;
        case BOW:
            return ((bow_t*) weapon)->name;
            break;
        case SHIELD:
            return ((shield_t*) weapon)->name;
            break;
        case SWORD:
            return ((sword_t*) weapon)->name;
            break;
        case LONGSWORD:
            return ((longsword_t*) weapon)->name;
            break;
        case SPEAR:
            return ((spear_t*) weapon)->name;
            break;
        case EPICSHIELD:
            return ((epic_shield_t*) weapon)->name;
            break;
        case KATANA:
            return ((katana_t*) weapon)->name;
            break;
        default:
            return "";
    }
}

char* getFoeName(){
    if(foe == NULL){
        return "";
    } else {
        return foe_names[foe->type];
    }
}

void switchWeapon(void** hand, weapon_type weapon_type){
    switch(weapon_type){
        case TOOTHPICK:
            *hand = realloc(*hand, sizeof(toothpick_t));
            ((toothpick_t*) *hand)->weapon.type = TOOTHPICK;
            ((toothpick_t*) *hand)->weapon.damage = 1;
            ((toothpick_t*) *hand)->weapon.defense = 0;
            ((toothpick_t*) *hand)->weapon.level = 0;
            strcpy(((toothpick_t*) *hand)->art, "<--->");
            readWeaponName(((toothpick_t*) *hand)->name);
            break;
        case DAGGER:
            *hand = realloc(*hand, sizeof(dagger_t));
            ((dagger_t*) *hand)->weapon.type = DAGGER;
            ((dagger_t*) *hand)->weapon.damage = 5;
            ((dagger_t*) *hand)->weapon.defense = 3;
            ((dagger_t*) *hand)->weapon.level = 1;
            strcpy(((dagger_t*) *hand)->art, "[]++++||=======>");
            readWeaponName(((dagger_t*) *hand)->name);
            break;
        case AXE:
            *hand = realloc(*hand, sizeof(axe_t));
            ((axe_t*) *hand)->weapon.type = AXE;
            ((axe_t*) *hand)->weapon.damage = 8;
            ((axe_t*) *hand)->weapon.defense = 5;
            ((axe_t*) *hand)->weapon.level = 2;
            strcpy(((axe_t*) *hand)->art, "  .\n_/ `.\n#   .\n#\\.`\n#\n#\n#\n#");
            readWeaponName(((axe_t*) *hand)->name);
            break;
        case BOW:
            *hand = realloc(*hand, sizeof(bow_t));
            ((bow_t*) *hand)->weapon.type = BOW;
            ((bow_t*) *hand)->weapon.damage = 7;
            ((bow_t*) *hand)->weapon.defense = 1;
            ((bow_t*) *hand)->weapon.level = 3;
            strcpy(((bow_t*) *hand)->art, "   (\n    \\\n     )\n##-------->\n     )\n    /\n   (");
            readWeaponName(((bow_t*) *hand)->name);
            break;
        case SHIELD:
            *hand = realloc(*hand, sizeof(shield_t));
            ((shield_t*) *hand)->weapon.type = SHIELD;
            ((shield_t*) *hand)->weapon.damage = 1;
            ((shield_t*) *hand)->weapon.defense = 10;
            ((shield_t*) *hand)->weapon.level = 4;
            strcpy(((shield_t*) *hand)->art, "._______.\n|__| |__|\n|__   __|\n|  | |  |\n \\ | | /\n  \\|_|/");
            readWeaponName(((shield_t*) *hand)->name);
            break;
        case SWORD:
            *hand = realloc(*hand, sizeof(sword_t));
            ((sword_t*) *hand)->weapon.type = SWORD;
            ((sword_t*) *hand)->weapon.damage = 10;
            ((sword_t*) *hand)->weapon.defense = 7;
            ((sword_t*) *hand)->weapon.level = 5;
            strcpy(((sword_t*) *hand)->art, "       .\n      /| ________________\nO|===|* >________________>\n      \\|\n       `");
            readWeaponName(((sword_t*) *hand)->name);
            break;
        case LONGSWORD:
            *hand = realloc(*hand, sizeof(longsword_t));
            ((longsword_t*) *hand)->weapon.type = LONGSWORD;
            ((longsword_t*) *hand)->weapon.damage = 10;
            ((longsword_t*) *hand)->weapon.defense = 7;
            ((longsword_t*) *hand)->weapon.level = 6;
            strcpy(((longsword_t*) *hand)->art, "        />________________________________\n[#######[]________________________________>\n        \\>");
            readWeaponName(((longsword_t*) *hand)->name);
            break;
        case SPEAR:
            *hand = realloc(*hand, sizeof(spear_t));
            ((spear_t*) *hand)->weapon.type = SPEAR;
            ((spear_t*) *hand)->weapon.damage = 10;
            ((spear_t*) *hand)->weapon.defense = 7;
            ((spear_t*) *hand)->weapon.level = 7;
            strcpy(((spear_t*) *hand)->art, "   .\n  / \\\n /_*_\\\n  | |\n  | |\n  | |\n  | |\n  | |\n  |=|\n  |=|\n  |=|\n  | |\n  | |\n  | |\n  | |\n  | |\n  | |");
            readWeaponName(((spear_t*) *hand)->name);
            break;
        case EPICSHIELD:
            *hand = realloc(*hand, sizeof(epic_shield_t));
            ((epic_shield_t*) *hand)->weapon.type = EPICSHIELD;
            ((epic_shield_t*) *hand)->weapon.damage = 10;
            ((epic_shield_t*) *hand)->weapon.defense = 7;
            ((epic_shield_t*) *hand)->weapon.level = 8;
            strcpy(((epic_shield_t*) *hand)->art, "    _..._\n.-'_.---._'-.\n||####|(__)||\n((####|(**)))\n '\\###|_''/'\n  \\\\()|##//\n   \\\\ |#//\n    .\\_/.\n     L.J\n      \"");
            readWeaponName(((epic_shield_t*) *hand)->name);
            break;
        case KATANA:
            *hand = realloc(*hand, sizeof(katana_t));
            ((katana_t*) *hand)->weapon.type = KATANA;
            ((katana_t*) *hand)->weapon.damage = 10;
            ((katana_t*) *hand)->weapon.defense = 7;
            ((katana_t*) *hand)->weapon.level = 8;
            strcpy(((katana_t*) *hand)->art, "            /\\\n/vvvvvvvvvvvv \\--------------------------------------,\n`^^^^^^^^^^^^ /=====================================\"\n            \\/");
            readWeaponName(((katana_t*) *hand)->name);
            break;
        default:
            break;
    }
}

void printSwitchWeaponHandMenu(){
    puts("> Select a hand:");
    puts("> 1) left");
    puts("> 2) right");
    puts("> Your choice:");
}

void printSwitchWeaponWeaponMenu(){
    puts("> Select a weapon:");
    puts("> 1) toothpick");
    puts("> 2) dagger");
    puts("> 3) axe");
    puts("> 4) bow");
    puts("> 5) shield");
    puts("> 6) sword");
    puts("> 7) longsword");
    puts("> 8) spear");
    puts("> 9) epic shield");
    puts("> 10) katana");
    puts("> Your choice:");
}

void switchWeaponWrap(){
    unsigned int choice;
    void ** hand;
    weapon_type w_type;
    printSwitchWeaponHandMenu();
    readChoice(&choice);
    switch(choice){
        case 1:
            hand = &hero->left_hand;
            break;
        case 2:
            hand = &hero->right_hand;
            break;
        default:
            puts("error: please select either 1 or 2, a hero only has two hands");
            return;
    }
    printSwitchWeaponWeaponMenu();
    readChoice(&choice);
    switch(choice){
        case 1:
            w_type = TOOTHPICK;
            break;
        case 2:
            w_type = DAGGER;
            break;
        case 3:
            w_type = AXE;
            break;
        case 4:
            w_type = BOW;
            break;
        case 5:
            w_type = SHIELD;
            break;
        case 6:
            w_type = SWORD;
            break;
        case 7:
            w_type = LONGSWORD;
            break;
        case 8:
            w_type = SPEAR;
            break;
        case 9:
            w_type = EPICSHIELD;
            break;
        case 10:
            w_type = KATANA;
            break;
        default:
            printf("error: there is no such weapon '%u'\n", choice);
            return;
    }
    switchWeapon(hand, w_type);
}

void switchFoe(foe_type f_type){
    unsigned int size = 1;
    int health;
    int damage;
    unsigned int defense;
    size += sizeof(foe_t) + strlen(foe_arts[f_type]);
    switch(f_type){
        case FLEA:
            health = 1;
            damage = 1;
            defense = 1;
            break;
        case FISH:
            health = 4;
            damage = 2;
            defense = 3;
            break;
        case BUTTERFLY:
            health = 2;
            damage = 1;
            defense = 5;
            break;
        case DOG:
            health = 10;
            damage = 5;
            defense = 6;
            break;
        case BAT:
            health = 4;
            damage = 6;
            defense = 10;
            break;
        case DRAGON:
            health = 1000;
            damage = 100;
            defense = 100;
            break;
        case BIGBOSSDRAGON:
            if(FACED_BIG_BOSS){
                puts("a hero may only face the big boss dragon once");
                return;
            }
            health = 2000;
            damage = (int)(((unsigned long)&system) & 0xffffffff);
            defense = ((unsigned long)&system) >> 32;
            break;
        default:
            break;
    }
    foe = malloc(size);
    foe->type = f_type;
    foe->health = health;
    foe->damage = damage;
    foe->defense = defense;
    strcpy(foe->art, foe_arts[f_type]);
}

void printSwitchFoeMenu(){
    puts("> Select a foe:");
    puts("> 1) flea");
    puts("> 2) fish");
    puts("> 3) butterfly");
    puts("> 4) dog");
    puts("> 5) bat");
    puts("> 6) dragon");
    puts("> 7) big boss dragon");
    puts("> Your choice:");
}

void switchFoeWrap(){
    unsigned int choice;
    foe_type f_type;
    printSwitchFoeMenu();
    readChoice(&choice);
    switch(choice){
        case 1:
            f_type = FLEA;
            break;
        case 2:
            f_type = FISH;
            break;
        case 3:
            f_type = BUTTERFLY;
            break;
        case 4:
            f_type = DOG;
            break;
        case 5:
            f_type = BAT;
            break;
        case 6:
            f_type = DRAGON;
            break;
        case 7:
            f_type = BIGBOSSDRAGON;
            break;
        default:
            puts("error: please select a valid foe");
            return;
    }
    switchFoe(f_type);
    if(hero->left_hand != NULL && hero->right_hand != NULL && getWeaponType(hero->left_hand) == getWeaponType(hero->left_hand)){
        puts("using same weapon in both hands, activating berserker mode!!");
    }
}

strike_outcome_e check_healths(){
    if(hero->health <= 0){
        if(foe->health <= 0){
            return BOTH_DEAD;
        } else {
            return HERO_DEAD;
        }
    } else {
        if(foe->health <= 0){
            return FOE_DEAD;
        } else {
            return BOTH_SURVIVED;
        }
    }
}

void damageHero(){
    unsigned int defense = 0;
    if(hero->left_hand != NULL){
        defense += getWeaponDefense(hero->left_hand);
    }
    if(hero->right_hand != NULL){
        defense += getWeaponDefense(hero->right_hand);
    }
    if(foe->damage > defense){
        hero->health -= (foe->damage - defense);
    }
}

void damageFoe(){
    int damage = 0;
    int damage_multiplier = 1;
    if(hero->left_hand != NULL){
        damage += getWeaponDamage(hero->left_hand);
    }
    if(hero->right_hand != NULL){
        damage += getWeaponDamage(hero->right_hand);
    }
    if(hero->left_hand != NULL && hero->right_hand != NULL && getWeaponType(hero->left_hand) == getWeaponType(hero->left_hand)){
        damage_multiplier = 2;
    }

    damage *= damage_multiplier;

    if(damage > foe->defense){
        foe->health -= (damage - foe->defense);
    }
}

void strikeFoe(){
    if(foe == NULL){
        puts("error: you haven't selected a foe yet");
        return;
    }
    if(hero->left_hand == NULL && hero->right_hand == NULL){
        printf("it is unwise to fight bare-handed with a %s\n", getFoeName());
        damageHero();
    } else {
        damageHero();
        damageFoe();
    }
    switch(check_healths()){
        case HERO_DEAD:
            printf("a mighty %s defeated a hero\n", getFoeName());
            exit(0);
        case FOE_DEAD:
            printf("a hero slayed a %s\n", getFoeName());
            char buf[256];
            snprintf(buf, 256, "%s slayer ", getFoeName());
            unsigned int new_name_part_len = strlen(buf);
            if(hero->main_hand == LEFT){
                memcpy(getWeaponName(hero->left_hand) + new_name_part_len, getWeaponName(hero->left_hand), WEAPON_NAME_MAX_SIZE);
                memcpy(getWeaponName(hero->left_hand), buf, new_name_part_len);
            } else {
                memcpy(getWeaponName(hero->right_hand) + new_name_part_len, getWeaponName(hero->right_hand), WEAPON_NAME_MAX_SIZE);
                memcpy(getWeaponName(hero->right_hand), buf, new_name_part_len);
            }
            foe = NULL;
            break;
        case BOTH_DEAD:
            printf("it was a massacre, both a hero and a %s is dead\n", getFoeName());
            exit(0);
        case BOTH_SURVIVED:
            puts("noone stroke a deadly blow");
            break;
        default:
            break;
    }
}

void switchHand(){
    if(hero->main_hand == LEFT){
        hero->main_hand = RIGHT;
        puts("Switched to right hand");
    } else {
        hero->main_hand = LEFT;
        puts("Switched to left hand");
    }
}

void cheat(){
    char buf[15];
    puts("oh so you are a cheater ok, let me ask you some questions");
    puts("if you answer well I'll let you advance");
    puts("What is the base address of the heap? (format: 0x5612e9995000)");
    read(1, buf, 15);
    buf[15] = '\0';
    if(((void*) hero) - 0x02a0 != (void*) strtol(buf, NULL, 16)){
        printf("%p\n", ((void*) hero) - 0x02a0);
        printf("%p\n", strtol(buf, NULL, 16));
        puts("no luck, bye");
        exit(0);
    }
    puts("Well done, now what is the base address of libc? (format: 0x7f236aa8e000)");
    read(1, buf, 15);
    buf[15] = '\0';
    if((&system - 0x49de0) != (void*) strtol(buf, NULL, 16)){
        puts("no luck, bye");
        exit(0);
    }

    puts("okok, here is your flag:");

    FILE *flag_f  = fopen("flag", "r");
    if (flag_f == NULL){
        puts("error: could not open flag file");
        exit(-1);
    }

    char flag[50];
    fscanf(flag_f, "%s", flag);
    puts(flag);
    fclose(flag_f);

    exit(0);
}

void printHero(){
    puts("=== hero ===");
    printf("health: %u\n", hero->health);
    if(hero->left_hand == NULL){
        puts("left hand: empty");
    } else {
        printf("left hand:\n@-- %s --@\nimage:\n%s\ndamage: %d\ndefense: %u\n", getWeaponName(hero->left_hand), getWeaponArt(hero->left_hand), getWeaponDamage(hero->left_hand), getWeaponDefense(hero->left_hand));
    }
    if(hero->right_hand == NULL){
        puts("right hand: empty");
    } else {
        printf("right hand:\n@-- %s --@\nimage:\n%s\ndamage: %d\ndefense: %u\n", getWeaponName(hero->right_hand), getWeaponArt(hero->right_hand), getWeaponDamage(hero->right_hand), getWeaponDefense(hero->right_hand));
    }
}

void printFoe(){
    puts("=== foe ===");
    if(foe == NULL){
        puts("foe is yet to be selected");
    } else {
        puts(foe_names[foe->type]);
        puts(foe_arts[foe->type]);
        printf("health: %u\n", foe->health);
        printf("damage:%d\ndefense:%u\n", foe->damage, foe->defense);
    }
}

void printWelcome(){
    puts("    )                                                 ");
    puts(" ( /(                       (                      )  ");
    puts(" )\\())   (     )          ( )\\     (     (      ( /(  ");
    puts("((_)\\   ))\\ ( /(  `  )    )((_)   ))\\   ))\\ (   )\\()) ");
    puts(" _((_) /((_))(_)) /(/(   ((_)_   /((_) /((_))\\ (_))/  ");
    puts("| || |(_)) ((_)_ ((_)_\\   / _ \\ (_))( (_)) ((_)| |_   ");
    puts("| __ |/ -_)/ _` || '_ \\) | (_) || || |/ -_)(_-<|  _|  ");
    puts("|_||_|\\___|\\__,_|| .__/   \\__\\_\\ \\_,_|\\___|/__/ \\__|  ");
    puts("                 |_|                                  ");
}

void printMenu(){
    puts("> A hero may:");
    puts("> 1) switch the weapon in one of their hands");
    puts("> 2) challenge another foe");
    puts("> 3) strike the current foe");
    puts("> 4) switch main hand");
    puts("> Your choice:");
}

int main (int argc, char **argv){
    unsigned int choice;

    setvbuf(stdin,NULL,_IONBF,0);
    setvbuf(stdout,NULL,_IONBF,0);

    hero = (hero_t*) malloc(sizeof(hero));
    hero->health = 100;
    hero->main_hand = LEFT;
    hero->left_hand = NULL;
    hero->right_hand = NULL;

    foe = NULL;

    printWelcome();

    while(1){
        printHero();
        printFoe();
        printMenu();
        readChoice(&choice);
        switch(choice){
            case 1:
                switchWeaponWrap();
                break;
            case 2:
                switchFoeWrap();
                break;
            case 3:
                strikeFoe();
                break;
            case 4:
                switchHand();
                break;
            case 0x1337:
                cheat();
                break;
            default:
                exit(0);
        }
    }
    return 0;
}
