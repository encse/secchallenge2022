gcc -O0 -Wl,-rpath=./libs,--dynamic-linker=./libs/ld-2.33.so -o ./bin/heap-quest ./src/heap-quest.c
